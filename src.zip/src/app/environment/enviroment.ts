export const environment = {

  apiuri: 'http://localhost:8080/api',
  apiuriPublic: 'http://localhost:8080',

};
