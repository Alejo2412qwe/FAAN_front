export class PeyloadNumeroAdopcionRaza {
    nombreRaza?: string;
    numeroAdopcion?: string;
}