export class VacunasAnimales{
    estadoVacuna!:  string;
    fechaVacuna!:   Date;
    nombreVacuna!:  string;
    observaciones!: string;
}