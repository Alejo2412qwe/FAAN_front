export class PeyloadNumeroAdopcionFecha {
    numeroAdopcionFecha?: string;
    fechaAdopcion?: string;
}