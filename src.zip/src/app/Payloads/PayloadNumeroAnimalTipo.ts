export class NumeroAnimalTipo{
    nombreTipo!:  string;
    numerotipo!:  string;
}