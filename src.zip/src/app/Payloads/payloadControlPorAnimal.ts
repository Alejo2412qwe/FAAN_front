export class PayloadControlAnimal{
    idControlAnimal!: number;
    nombreVeterinario!:    string;
    fechaControlAnimal!:   Date;
    pesoActual!: number;
    tipoEstadoAnimal!: string;
    descripcion!: string;

}