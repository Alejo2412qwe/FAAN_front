export class TipoAnimal {
    idTipoAnimal?: number;
    nombreTipo?: string;
    descripcionAnimal?: string;
    estadoTipo?: string;
}