export class Notificaciones {
    get_id?: string;
    fullNameMascota?: string;
    cuerpoMensaje?: string;
    diasFaltantes?: string;
    estadoNotifacion?: string;
    proximaFechaFacunacion?: Date;
}