export class TipoVacuna {
    idTipoVacuna!: number;
    nombreVacuna?: string;
    estado?: boolean;
}
