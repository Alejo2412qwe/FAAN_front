export class SituacionIngreso {
    idSituacionIngreso?: number;
    nombreSituacionIngreso?: string;
    estadoSituacionIngreso?: string;
}