import { Animal } from "./animal";
export class EstadoAnimal {
    idEstadoAnimal?: number;
    tipoEstadoAnimal?: string;
    descripcion?: string;
    estado?: string;
}