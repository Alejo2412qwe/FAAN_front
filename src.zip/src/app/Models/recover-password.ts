export class RecoverPassword {
    password?: string;
    passwordr?: string;
    token?: string;
}
