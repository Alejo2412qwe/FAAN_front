export class Fundacion {
    idFudacion?: number;
    ruc?: string;
    nombreFundacion?: string;
    eslogan?: string;
    objetivo?: string;
    correo?: string;
    direccion?: string;
    paginaWeb?: string;
    horarios?: string;
    acronimo?: string;
    logoFundacion?: string;
}
