import { TipoAnimal } from "./tipoAnimal";

export class RazaAnimal {
    idRazaAnimal?: number;
    nombreRaza?: string;
    estadoRaza?: string;
    tipoAnimal?: TipoAnimal;
}